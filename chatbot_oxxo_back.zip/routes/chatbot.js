// routes/users.js
const express = require('express');
const router = express.Router();

const chatbot_controller = { 
    sendMessagge
} = require('../controllers/ChatbotController.js')

// Define a route
router.post('/mensaje', chatbot_controller.sendMessagge);

// export the router module so that server.js file can use it
module.exports = router;