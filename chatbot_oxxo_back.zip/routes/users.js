// routes/users.js
const express = require('express');
const router = express.Router();

const users_controller = { 
    login
} = require('../controllers/UsersController.js')

// Define a route
router.post('/login', users_controller.login);

// export the router module so that server.js file can use it
module.exports = router;