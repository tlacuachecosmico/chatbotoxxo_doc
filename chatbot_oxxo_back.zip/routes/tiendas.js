// routes/users.js
const express = require('express');
const router = express.Router();

const tiendas_controller = { 
    getPlazas,
    getTiendas
} = require('../controllers/TiendasController.js')

// Define a route
router.get('/plazas', tiendas_controller.getPlazas);
router.get('/:plazaId', tiendas_controller.getTiendas);

// export the router module so that server.js file can use it
module.exports = router;