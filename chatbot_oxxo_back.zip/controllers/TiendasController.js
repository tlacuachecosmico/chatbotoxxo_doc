const db = require("../config/db.js");
const XXVA_ENG_PLAZA = db.XXVA_ENG_PLAZA;
const XXVA_ENG_TIENDAS = db.XXVA_ENG_TIENDAS;

const getPlazas = (async (req, res) => {
    const data = await XXVA_ENG_PLAZA.findAll();
    res.json(data)
})

const getTiendas = (async (req, res) => {
    const plazaId = req.params.plazaId;
    if (!plazaId) {
        res.status(400).send({
          message: "PLAZA_ID can not be empty!"
        });
        return;
      }
    const data = await XXVA_ENG_TIENDAS.findAll({ where: { PLAZA_ID: plazaId } });
    res.json(data);
})

module.exports = {
    getPlazas,
    getTiendas
}