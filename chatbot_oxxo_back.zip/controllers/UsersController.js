const db = require("../config/db.js");
const XXVA_BOT_USERS = db.XXVA_BOT_USERS;
const jwt = require('jsonwebtoken');
require('dotenv').config();

const login = (async (req, res) => {
    const plazaId = req.body.plazaId;
    if (!plazaId) {
        res.status(400).send({
          message: "PLAZA_ID can not be empty!"
        });
        return;
    }
    const tiendaId = req.body.tiendaId;
    if (!tiendaId) {
        res.status(400).send({
          message: "TIENDA_ID can not be empty!"
        });
        return;
    }
    const user = req.body.user;
    if (!user) {
        res.status(400).send({
          message: "USER can not be empty!"
        });
        return;
    }
    const password = req.body.password;
    if (!password) {
        res.status(400).send({
          message: "PASWORD can not be empty!"
        });
        return;
    }
    const data = await XXVA_BOT_USERS.findOne(
        { where: 
            { 
                PLAZA_ID: plazaId, 
                TIENDA_ID: tiendaId ,
                USER_CODE: user,
                USER_PASSWORD: password
            } 
        }
    );
    if (!data) {
        res.status(401).send({
          message: "Authentication failed!"
        });
        return;
    }
    const token = jwt.sign({ userId: data.id }, process.env.TOKEN_KEY, {
        expiresIn: '8h',
    });
    const username = `${data.USER_NAME} ${data.USER_FIRSTNAME}`;
    res.json({token: token, username:username});
})

module.exports = {
    login
}