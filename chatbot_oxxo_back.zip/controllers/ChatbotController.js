const db = require("../config/db.js");
const { Op } = require('sequelize');
const XXVA_BOT_SERVICES = db.XXVA_BOT_SERVICES;
const OpenAI = require("openai");

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

const sendMessagge = (async (req, res) => {
    const userMessage = req.body.usserMessagge;
    if('hola' == userMessage.toLowerCase() || 'hola.' == userMessage.toLowerCase()){
        res.json({respuesta: "Hola, ¿En que puedo ayudarte?."});
    }else{
        const keyWordWOFilter = await findKeyWords(userMessage);
        const keyWords = await filterKeyWords(keyWordWOFilter);
        //console.log(keyWords);
        if(keyWords==''){
            res.json({respuesta: "Lo siento, no pude encontrar una respuesta adecuada a tu mensaje."});
        }else if(keyWords!=''){
            const context = await findServices(keyWords);
            if(context!=''){
                if(context.split('\n').length>3){
                    res.json({respuesta: "Se encontraron demasiadas coincidencias, ayudame a precisar tu pregunta."})
                }else{
                    const mensageOpenai = '"Aquí tienes información relevante extraída de la base de datos: ' + 
                    context +
                    'Con base en esta información, responde la siguiente pregunta de manera clara y precisa: ' +
                    userMessage +'"';
                    const respuesta = await openai.chat.completions.create({
                        model: "gpt-3.5-turbo",
                        messages: [{role: "user", content: mensageOpenai}],
                        temperature: 0.7,
                    });
                    res.json({respuesta: respuesta.choices[0].message.content});
                    //console.log(context);
                    //res.json({respuesta: 'Texto generico'})
                }
            }else{
                res.json({respuesta: "Lo siento, no pude encontrar una respuesta adecuada a tu mensaje."});
            }
        }else{
            res.json({respuesta: "Lo siento, no pude encontrar una respuesta adecuada a tu mensaje."})
        }
    }
    
})

const findKeyWords = (async (userMessagge) => {
    if(userMessagge.toLowerCase().includes('servicio')){
        //const ms = userMessagge.toLowerCase().replace('a',' ');
        //console.log('mensaje: '+ms);
        const arr_Messagge = userMessagge.toLowerCase().replace('?','').replace(', ',' ').replace(' ,',' ').split('servicio ');
        if(arr_Messagge.length>1){
            if(arr_Messagge[1].substring(0,3) == 'de '){
                if(arr_Messagge[1].substring(arr_Messagge[1].length - 1) == '.'){
                    const arr_service = arr_Messagge[1].substring(3,arr_Messagge[1].length-1);
                    return arr_service;
                }else{
                    const arr_service = arr_Messagge[1].substring(3,arr_Messagge[1].length);
                    return arr_service;
                }
            }
            if(arr_Messagge[1].substring(arr_Messagge[1].length - 1)== '.'){
                const arr_service = arr_Messagge[1].substring(0,arr_Messagge[1].length-1);
                return arr_service;
            }
            return arr_Messagge[1];
        }
        return '';
    }else{
        const arr_Messagge = userMessagge.toLowerCase().replace('?','').replace(', ',' ').replace(' ,',' ').split('servicio ');
        if(arr_Messagge.length > 0){
            if(userMessagge.toLowerCase().substring(userMessagge.length - 1) == '.'){
                const arr_service = userMessagge.toLowerCase().substring(0,userMessagge.length-1);
                return arr_service;
            }else{
                return userMessagge.toLowerCase().replace('?','').replace(', ',' ').replace(' ,',' ');
            }
        }
            
        return '';
    }
    
})

const filterKeyWords = (async (keyWords) => {
    const arr_keyWords = keyWords.split(' ');
    let responseData = '';
    for(let keyWord of arr_keyWords){
        if(keyWord == 'con' || keyWord == 'desde')
            break
        responseData += keyWord + ' ';
    }
    return responseData.trim();
})

const findServices = (async (keyWords) => {
    let responseData = '';
    const data = await XXVA_BOT_SERVICES.findAll({ where: { NAME_SERVICE: {[Op.like]: '%'+keyWords+'%'} } });
    responseData = await concatContext(data);
    if(responseData == ''){
        responseData = await concatContextSplit(keyWords);
    }
    return responseData;
})

const concatContext = ( async (data) => {
    let services = [];
    let responseData = '';
    for(let service of data){
        if(!services.includes(service.ID)){
            console.log(service.NAME_SERVICE)
            services.push(service.ID);
            const menu = service.SERVICE_MENU == 1 ? 'SI' : 'NO';
            const pago_tarjeta = service.CARD_PAYMENT == 1 ? 'SI' : 'NO';
            const pago_atrasado = service.PAYMENTS_OVERDUE == 1 ? 'SI' : 'NO'
            responseData += 
                'Servicio: ' + service.NAME_SERVICE +
                ', se encuentra en el menu de servicios: ' + menu +
                ', comision pesos: ' + service.COMMISSION +
                ', acepta pago con tarjeta: ' + pago_tarjeta +
                ', acepta pagos vencidos: ' + pago_atrasado + "\n";
        }
    }
    return responseData;
})

const concatContextSplit = ( async (keyWords) => {
    let services = [];
    let responseData = '';
    const arr_service = keyWords.split(' ');
    for(let name_service of arr_service){
        const dataSplit = await XXVA_BOT_SERVICES.findAll({ where: { NAME_SERVICE: {[Op.like]: '%'+name_service+'%'} } });
        for(let service of dataSplit){
            if(!services.includes(service.ID)){
                console.log(service.NAME_SERVICE)
                services.push(service.ID);
                const menu = service.SERVICE_MENU == 1 ? 'SI' : 'NO';
                const pago_tarjeta = service.CARD_PAYMENT == 1 ? 'SI' : 'NO';
                const pago_atrasado = service.PAYMENTS_OVERDUE == 1 ? 'SI' : 'NO'
                responseData += 
                    'Servicio: ' + service.NAME_SERVICE +
                    ', se encuentra en el menu de servicios: ' + menu +
                    ', comision pesos: ' + service.COMMISSION +
                    ', acepta pago con tarjeta: ' + pago_tarjeta +
                    ', acepta pagos vencidos: ' + pago_atrasado + "\n";
            }
        }
    }
    return responseData;
})

module.exports = {
    sendMessagge
}