module.exports = (sequelize, Sequelize) => {
    const Users = sequelize.define("XXVA_BOT_USERS", {
	    USER_NAME: {
            type: Sequelize.STRING
        },
	    USER_FIRSTNAME: {
            type: Sequelize.STRING
        },
	    USER_LASTNAME: {
            type: Sequelize.STRING
        },
	    USER_CODE: {
            type: Sequelize.STRING
        },
	    USER_PASSWORD: {
            type: Sequelize.STRING
        },	    
        PLAZA_ID: {
            type: Sequelize.STRING
        },
	    TIENDA_ID: {
            type: Sequelize.STRING
        },
    },{
        freezeTableName: true
    });
    
    return Users;
};