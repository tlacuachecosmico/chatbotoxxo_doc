module.exports = (sequelize, Sequelize) => {
    const Tiendas = sequelize.define("XXVA_ENG_TIENDAS", {
        PLAZA_ID: {
            type: Sequelize.STRING
        },
        TIENDA_ID: {
            type: Sequelize.STRING
        },
    },{
        freezeTableName: true
    });

    Tiendas.removeAttribute('id');
    
    return Tiendas;
};