module.exports = (sequelize, Sequelize) => {
    const Servicios = sequelize.define("XXVA_BOT_SERVICES", {
        ID: {
            type: Sequelize.INTEGER
        },
        ITEM: {
            type: Sequelize.INTEGER
        },
        NAME_SERVICE: {
            type: Sequelize.STRING
        },
        TYPE_SERVICE: {
            type: Sequelize.STRING
        },
        INDUSTRI: {
            type: Sequelize.STRING
        },
        SERVICE_MENU: {
            type: Sequelize.INTEGER
        },
        BARCODE: {
            type: Sequelize.INTEGER
        },
        BOTH_SIDE: {
            type: Sequelize.INTEGER
        },
        REACH: {
            type: Sequelize.STRING
        },
        COMMISSION: {
            type: Sequelize.FLOAT
        },
        CARD_PAYMENT: {
            type: Sequelize.INTEGER
        },
        PAYMENTS_OVERDUE: {
            type: Sequelize.INTEGER
        },
        PLAZA_ID: {
            type: Sequelize.STRING
        },
    },{
        freezeTableName: true
    });
    
    return Servicios;
};