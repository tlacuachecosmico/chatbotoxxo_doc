module.exports = (sequelize, Sequelize) => {
    const Plazas = sequelize.define("XXVA_ENG_PLAZA", {
        PLAZA_ID: {
            type: Sequelize.STRING
        },
    },{
        freezeTableName: true
    });

    Plazas.removeAttribute('id');
    
    return Plazas;
};