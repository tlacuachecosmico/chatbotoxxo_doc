// fileName : server.js 
const express = require('express');
const app = express();
const cors=require('cors');
const bodyParser = require('body-parser');

require('dotenv').config();

//const options = {
//    origin: 'http://localhost:3000',
//}
//app.use(cors(options))
app.options('*', cors());
app.use(cors());
app.use(bodyParser.json())


const db = require("./config/db.js");

db.sequelize.sync();

// Include route files
const usersRoute = require('./routes/users');
const tiendasRoute = require('./routes/tiendas');
const chatbot = require('./routes/chatbot');

// Use routes
app.use('/users', usersRoute);
app.use('/tiendas', tiendasRoute);
app.use('/chatbot', chatbot);

// Example specifying the port and starting the server
const port = process.env.APP_PORT || 4000; // You can use environment variables for port configuration
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});